# Gotham Unbound — Standalone

A normal, independent web app — no Claude account or connection needed. This
has been fixed up and verified for real deployment: correct relative asset
paths (works at any URL depth), a proper app icon set, and a full installable
PWA (offline app shell + home-screen install prompt, not just "Add to Home
Screen").

## Bring your existing data over (optional)

If you've used the app inside Claude and want to keep your history:

1. In the Claude-hosted version: **More → Backup & Restore → Export Data**
2. Open the standalone version (any option below)
3. **More → Backup & Restore → Import Data**, and choose that exported file

## Deploy to GitHub Pages (recommended — free, permanent URL)

1. Create a new GitHub repo and push this folder to it (`main` branch)
2. In the repo: **Settings → Pages → Build and deployment → Source → GitHub Actions**
3. Push to `main` — the included workflow (`.github/workflows/deploy.yml`)
   builds and publishes automatically. Check the **Actions** tab for progress
4. Your app is live at `https://<your-username>.github.io/<repo-name>/`
5. On your phone, open that URL and use **Add to Home Screen** (iOS) or the
   **Install** prompt (Android/Chrome) — it'll behave like a real installed app

No manual `base` path configuration needed — it's already set to work from
any subpath.

## Deploy to Netlify / Vercel / Cloudflare Pages

Connect the repo (or drag-and-drop the `dist/` folder after running
`npm run build` onto [Netlify Drop](https://app.netlify.com/drop)). Build
command: `npm run build`. Output directory: `dist`. That's it — these
platforms auto-detect Vite.

## Run it in your browser first, no install (StackBlitz / CodeSandbox)

Start a new Vite + React project there, replace its files with this folder's
files (same structure), and it runs immediately with a live preview URL.

## Run it on your own computer

Requires [Node.js](https://nodejs.org).

```
npm install
npm run dev      # local dev server
npm run build    # production build -> dist/
npm run preview  # serve that production build locally to sanity-check it
```

## What's actually in here

- `src/storage-shim.js` — replaces Claude's built-in storage with the
  browser's own (IndexedDB), so data lives on your device
- `src/GothamUnbound.jsx` — the app itself, unchanged
- Everything else (manifest, icons, service worker, GitHub Actions workflow)
  is deployment plumbing — you shouldn't need to touch it

Your data is per-browser. If you switch phones or browsers, use
Export/Import (above) to carry it over. The one feature that needs an
internet connection to work is the exercise demo animations (they fetch from
ExerciseDB); everything else works fully offline once installed.
